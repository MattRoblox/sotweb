--INSTRUCTIONS--

	Open CS2 to the main menu.
	Make sure Steam Overlay is enabled and working in CS2.
	Right click notepad.exe
	Click "Run as Admin".
	You should now see "CS2 Free" in the corner of your screen.
	Press DEL to open the menu.
	You can now join a game and play.



--HOW TO OPEN MENU--

	Press DELETE (DEL) to open and close the menu.



--AIMBOT--

	Please see the aimbot.txt file for instructions how to use the aimbot.



--HELP--

If the watermark and menu is working but the cheats are not visible in game, it likely means CS2 updated, you need to wait for the new file to be released on the website.

If you cannot see the watermark it means there was a problem with gameoverlay or antivirus is blocking 	the injection. In this case, you should uninstall your antivirus.

1. Turn off windows defender
2. Turn off windows defender firewall
3. Turn off smartscreen (app and browser control)
4. Turn UAC to a low setting.